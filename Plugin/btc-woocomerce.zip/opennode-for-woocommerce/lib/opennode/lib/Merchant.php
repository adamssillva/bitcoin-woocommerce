<?php
namespace OpenNode;

class Merchant {}
